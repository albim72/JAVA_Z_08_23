package com.example.poletxt;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    private TextField daneTxt;

    @FXML
    private Spinner spinv;

    @FXML
    protected void onHelloButtonClick() {
        Double tx = Double.valueOf(daneTxt.getText());
        Integer dx = (Integer) spinv.getValue();
        Double vr = tx*dx;
        welcomeText.setText(vr.toString());
    }
}