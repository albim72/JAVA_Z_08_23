# A-JavaFX-Login-and-Sign-Up-Form
This application is a simple example of a JavaFX Login and Sign Up form. It involves use of methods to check if the fields are empty, fully filled or if the passwords match during signing up.

## Final Product

![Final App Image](Final-product.png)

It can show unfilled fields and errors in the form

![Checks](Checks.png "Checks")
